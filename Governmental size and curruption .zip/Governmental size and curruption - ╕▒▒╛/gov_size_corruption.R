#安装必要的包
install.packages("pacman")
library(pacman)
pacman::p_load(pacman,dplyr,GGally,ggplot2,ggthemes,gganimate,lubridate,
               ggvis,httr,rio,shiny,stringr,tidyr,psych,tidyverse,readxl,
               magrittr,forcats,broom,caret,mice,readxl)
#导入数据
p_load(readxl)
relation17 <- read_excel("中国城市政商关系2017.xls") %>% 
  select(1,5,10:12) 
colnames(relation17) <- c("province","close","corruption","open", "year")

relation18 <- read_excel("中国城市政商关系2018.xlsx") %>% 
  select(1,5,10:12) 
colnames(relation18) <- c("province","close","corruption","open", "year")

relation20 <- read_excel("中国城市政商关系2020.xlsx") %>% 
  select(1,5,10:12) 
colnames(relation20) <- c("province","close","corruption","open", "year")

relation21 <- read_excel("中国城市政商关系2021.xlsx") %>% 
  select(1,5,10:12) 
colnames(relation21) <- c("province","close","corruption","open", "year")

relation22 <- read_excel("中国城市政商关系2022.xlsx") %>% 
  select(1,5,10:12) 
colnames(relation22) <- c("province","close","corruption","open", "year")

relation <- rbind(relation17,relation18,relation20,relation21,relation22) %>% 
  mutate(province = as.character(province),
         year = as.numeric(year),
         close = as.numeric(close),
         open = as.numeric(open),
         corruption = as.numeric(corruption)) %>%
  summarise(close = mean(close,na.rm = T),
            open = mean(open,na.rm = T),
            corruption = mean(corruption,na.rm = T),
            .by = c('province', 'year')) 

pub_exp <- read_excel("分省年度一般预算支出数据 .xls") %>% 
  rename(province = 地区) 
colnames(pub_exp) <- gsub("年","",colnames(pub_exp))
pub_exp <- pub_exp %>% 
  gather(key = year,-province,value = pub_exp) %>% 
  mutate(year = as.numeric(year),
         pub_exp = as.numeric(pub_exp))

gdp <- read_excel("分省年度GDP数据.xls") %>% 
  rename(province = 地区) 
colnames(gdp) <- gsub("年","",colnames(gdp))
gdp <- gdp %>% 
  gather(key = year,-province,value = gdp) %>% 
  mutate(year = as.numeric(year),
         gdp = as.numeric(gdp))

gdp_add <- read_excel("分省gdp增速年度数据.xls") %>% 
  rename(province = 地区)
colnames(gdp_add) <- gsub("年","",colnames(gdp_add))
gdp_add <- gdp_add %>% 
  gather(-province,key = year, value = gdp_add) %>% 
  mutate(year = as.numeric(year),
         gdp_add = as.numeric(gdp_add),
         gdp_add = gdp_add-100)


officer <- read_excel("分省年度公共组织就业人数数据.xls") %>% 
  rename(province = 地区) 
colnames(officer) <- gsub("年","",colnames(officer))
officer <- officer %>% 
  gather(-province,key = year, value = officer) %>% 
  mutate(year = as.numeric(year),
         officer = as.numeric(officer))

population <- read_excel("分省人口年度数据.xls") %>% 
  rename(province = 地区)
colnames(population) <- gsub("年","",colnames(population))
population <- population %>% 
  gather(-province,key = year, value = population) %>% 
  mutate(year = as.numeric(year),
         population = as.numeric(population))

region <- read_excel("省份分区.xlsx") 

# 合并数据 --------------------------------------------------------------------


sumdata <- full_join(pub_exp,gdp,by = c("province", "year")) %>% 
  full_join(gdp_add,by = c("province","year")) %>%
  full_join(officer,by = c("province","year")) %>% 
  full_join(population,by = c("province", "year")) %>%
  left_join(relation, ., by = c("province","year")) %>% 
  full_join(region,by = c("province")) %>%
  mutate(gov_size = pub_exp/gdp,
         officer_rate = officer/population*100)#每百人中公职人员数量
md.pattern(sumdata)
#描述性统计
p_load(table1)
sumdata %>% select(5,12,4,3,8,2,11)  %>% 
  table1(~corruption+gov_size+open+close+gdp_add|region,data = .)



lmfit <- lm(corruption ~ gov_size*open + gdp_add + close, data = sumdata)
summary(lmfit)

#可视化--------------
#对各省的gov_size进行排序后可视化
p_load(ggplot2)


sumdata %>% 
  filter(year == 2022) %>% 
  ggplot(aes(x = fct_reorder(province, -gov_size), y = gov_size,
             group = year)) +
  geom_point() +
  geom_line() +
  #facet_wrap(~year) +
  theme_bw() +
  labs(title = "officer_rate in 2022",
       x = "province",
       y = "officer_rate") +
  theme(#legend.position = "none",
    axis.text.x = element_text(angle = 45, hjust = 1))

#对各省的officer_rate进行排序后可视化
sumdata %>% 
  filter(year == 2022) %>% 
  ggplot(aes(x = fct_reorder(province, -officer_rate), y = officer_rate,
             group = year)) +
  geom_point() +
  geom_line() +
  #facet_wrap(~year) +
  theme_bw() +
  labs(title = "officer_rate in 2022",
       x = "province",
       y = "officer_rate") +
  theme(#legend.position = "none",
    axis.text.x = element_text(angle = 45, hjust = 1))




#  固定效应模型   ---------------------------------------------------------------

p_load(plm)
pdata <- pdata.frame(sumdata, index = c("region",'year'))
mf <- plm(corruption ~ gov_size + close  , data = pdata,effect = 'twoways' , model = "within") 
mr <- plm(corruption ~ gov_size  + close, data = pdata,effect = 'twoways' , model = "random") 
# 传统 Hausman检验
phtest(mf,mr)
# 稳健的Hausman检验
phtest(corruption ~ gov_size, data = pdata, method = "aux", vcov = vcovHC)
#拒绝零假设，采用固定效应模型；不拒绝，采用随机效应模型。这里用固定效应模型
plm(corruption ~ officer_rate + gdp_add + close  ,effect = 'twoways' , model = "within",
    data = pdata) %>% summary()

fixfit1 <- plm(corruption ~ gov_size,effect = 'twoways' , model = "within",
              data = pdata)

fixfit2 <- plm(corruption ~ gov_size + gdp_add + close,effect = 'twoways' , model = "within",
               data = pdata)

medfit1 <- plm(corruption ~ open + gdp_add + close,effect = 'twoways' , model = "within",
               data = pdata)

medfit2 <- plm(open ~ gov_size + gdp_add + close, effect = 'twoways' , model = "within",
    data = pdata)

#固定效应模型结果输出
p_load(stargazer)
stargazer(fixfit1,fixfit2,medfit1,medfit2, 
          type = "html", title = "Fixed Effect Model", 
          align = TRUE, column.separate = c(3,1),
          column.labels = c("corruption", "open"),
          dep.var.labels = "corruption", 
          digits = 3,style = 'apsr',
          out = "fixed_effect_model.html")

# 稳健性检验 --------------------------------------------------------------------

fixfit1 <- plm(corruption ~ officer_rate,effect = 'twoways' , model = "within",
               data = pdata)

fixfit2 <- plm(corruption ~ officer_rate + gdp_add + close,effect = 'twoways' , model = "within",
               data = pdata)

medfit1 <- plm(corruption ~ open + gdp_add + close,effect = 'twoways' , model = "within",
               data = pdata)

medfit2 <- plm(open ~ officer_rate + gdp_add + close, effect = 'twoways' , model = "within",
               data = pdata)
#稳健性检验结果输出
stargazer(fixfit1,fixfit2,medfit1,medfit2, 
          type = "html", title = "Fixed Effect Model", 
          align = TRUE, column.separate = c(3,1),
          column.labels = c("corruption", "open"),
          dep.var.labels = "corruption", 
          digits = 3,style = 'apsr',
          out = "robust_test.html")

###########以下内容不在本次分析范围内，仅供参考############################################
# 中介模型 --------------------------------------------------------------------
p_load(lavaan)

mod1 <-   '
    #direct effect
    corruption ~ c*gov_size + e*gdp_add + f*close
    
    #mediator
    open ~ 1 + a*gov_size  
    corruption ~ 1 + b*open  

    # indirect effect (a*b)
    ab := a*b # indirect effect of legacy on donation
    
    # total effect
    total := c + (a*b)
    
    #indirect effect ratio
    ratio := ab/total
'
fmod1 <-sem(mod1, data=sumdata, se="boot", bootstrap=1000)

#查看结果
summary(fmod1, standardized=T,rsquare=T)

#可以看到mediation的置信区间
#置信区间不包括0，则中介效应显著
parameterEstimates(fmod1)
lavaan::fitMeasures(fmod1)
semPlot::semPaths(fmod1, layout="tree", sizeMan=7, sizeInt = 4, style="ram", 
                  residuals=TRUE, rotation=2, intAtSide = FALSE, 
                  whatLabels = "est", nCharNodes = 0, normalize = FALSE)

